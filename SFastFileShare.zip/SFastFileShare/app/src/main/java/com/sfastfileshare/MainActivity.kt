package com.sfastfileshare

import android.Manifest
import android.app.Activity
import android.app.AlertDialog
import android.content.*
import android.content.pm.PackageManager
import android.database.Cursor
import android.net.Uri
import android.net.wifi.WpsInfo
import android.net.wifi.p2p.*
import android.os.Build
import android.os.Bundle
import android.provider.OpenableColumns
import android.provider.MediaStore
import android.view.Gravity
import android.view.View
import android.widget.*
import java.io.*
import java.net.InetAddress
import java.net.ServerSocket
import java.net.Socket
import java.util.concurrent.CountDownLatch
import java.util.concurrent.Executors
import java.util.concurrent.TimeUnit
import java.util.concurrent.atomic.AtomicBoolean
import kotlin.math.max

class MainActivity : Activity() {
    private lateinit var manager: WifiP2pManager
    private lateinit var channel: WifiP2pManager.Channel
    private lateinit var status: TextView
    private lateinit var devices: LinearLayout
    private lateinit var progress: ProgressBar
    private lateinit var progressText: TextView
    private lateinit var sendButton: Button
    private lateinit var cancelButton: Button
    private val executor = Executors.newCachedThreadPool()
    private val running = AtomicBoolean(false)
    private val cancelled = AtomicBoolean(false)
    private val receiverBusy = AtomicBoolean(false)
    private var receiverRegistered = false
    private var connected = false
    private var groupOwner = false
    private var remoteAddress: InetAddress? = null
    private var serverSocket: ServerSocket? = null
    @Volatile private var transferSocket: Socket? = null

    private val p2pReceiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context, intent: Intent) {
            when (intent.action) {
                WifiP2pManager.WIFI_P2P_STATE_CHANGED_ACTION -> {
                    val state = intent.getIntExtra(WifiP2pManager.EXTRA_WIFI_STATE, -1)
                    if (state == WifiP2pManager.WIFI_P2P_STATE_ENABLED) setStatus("Wi-Fi Direct အဆင်သင့်ဖြစ်ပါပြီ")
                    else setStatus("ဖုန်း Wi-Fi ကို ဖွင့်ပေးပါ")
                }
                WifiP2pManager.WIFI_P2P_PEERS_CHANGED_ACTION -> requestPeers()
                WifiP2pManager.WIFI_P2P_CONNECTION_CHANGED_ACTION -> {
                    if (!hasPermissions()) return
                    manager.requestConnectionInfo(channel) { info ->
                        if (info.groupFormed && info.groupOwnerAddress != null) {
                            connected = true
                            groupOwner = info.isGroupOwner
                            remoteAddress = info.groupOwnerAddress
                            setStatus(if (groupOwner) "ချိတ်ဆက်ပြီးပါပြီ • ဒီဖုန်းက လက်ခံမည့်ဖုန်းဖြစ်ပါတယ်" else "ချိတ်ဆက်ပြီးပါပြီ • ဖိုင်ပို့/လက်ခံနိုင်ပါတယ်")
                            startServerIfOwner()
                            runOnUiThread {
                                sendButton.isEnabled = !groupOwner
                                cancelButton.isEnabled = false
                            }
                        } else {
                            connected = false
                            remoteAddress = null
                            setStatus("ဖုန်းတစ်လုံးကို ရွေးပြီး Connect နှိပ်ပါ")
                            runOnUiThread { sendButton.isEnabled = false }
                            stopServer()
                        }
                    }
                }
            }
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        manager = getSystemService(Context.WIFI_P2P_SERVICE) as WifiP2pManager
        channel = manager.initialize(this, mainLooper, null)
        buildUi()
        askPermissions()
    }

    private fun buildUi() {
        val root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(22, 24, 22, 18); setBackgroundColor(0xFFF3F6FC.toInt()) }
        val header = TextView(this).apply { text = "S"; textSize = 44f; gravity = Gravity.CENTER; setTextColor(0xFF246BFD.toInt()); typeface = android.graphics.Typeface.DEFAULT_BOLD }
        root.addView(header, LinearLayout.LayoutParams(-1, 64))
        status = TextView(this).apply { text = "ဖုန်းနှစ်လုံးစလုံးမှာ S ကိုဖွင့်ပါ"; textSize = 14f; gravity = Gravity.CENTER; setTextColor(0xFF40516B.toInt()); setPadding(8, 14, 8, 14) }
        root.addView(status)
        val scan = makeButton("ဖုန်းရှာမယ်  •  FIND DEVICES") { discoverPeers() }
        root.addView(scan, matchWrap())
        root.addView(TextView(this).apply { text = "အနီးအနားရှိ ဖုန်းများ"; textSize = 16f; setTextColor(0xFF18345F.toInt()); setPadding(4, 18, 4, 8); typeface = android.graphics.Typeface.DEFAULT_BOLD })
        devices = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        val scroll = ScrollView(this).apply { addView(devices) }
        root.addView(scroll, LinearLayout.LayoutParams(-1, 0, 1f))
        sendButton = makeButton("ဖိုင်ရွေးပြီး ပို့မယ်  •  SEND FILES") { if (connected && !groupOwner) openFilePicker() else toast("ချိတ်ဆက်ထားသော လက်ခံမည့်ဖုန်းကို ရွေးပါ") }
        sendButton.isEnabled = false
        root.addView(sendButton, matchWrap())
        cancelButton = makeButton("ပို့ခြင်း / လက်ခံခြင်း ရပ်မယ်  •  CANCEL") { cancelTransfer() }
        cancelButton.isEnabled = false
        root.addView(cancelButton, matchWrap())
        progress = ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal).apply { max = 100; progress = 0 }
        root.addView(progress, LinearLayout.LayoutParams(-1, 12))
        progressText = TextView(this).apply { text = "Ready"; textSize = 12f; gravity = Gravity.CENTER; setTextColor(0xFF40516B.toInt()); setPadding(4, 8, 4, 4) }
        root.addView(progressText)
        root.addView(TextView(this).apply { text = "Wi-Fi Direct • Offline • Android 10+"; textSize = 11f; gravity = Gravity.CENTER; setTextColor(0xFF8491A5.toInt()); setPadding(0, 12, 0, 0) })
        root.addView(TextView(this).apply { text = "Created by LawShingLing MTS"; textSize = 12f; gravity = Gravity.CENTER; setTextColor(0xFF246BFD.toInt()); typeface = android.graphics.Typeface.create("sans-serif-medium", android.graphics.Typeface.NORMAL); setPadding(0, 8, 0, 0) })
        setContentView(root)
    }

    private fun makeButton(label: String, action: () -> Unit) = Button(this).apply {
        text = label; isAllCaps = false; textSize = 13f; setTextColor(-1); backgroundTintList = android.content.res.ColorStateList.valueOf(0xFF246BFD.toInt()); setOnClickListener { action() }
    }
    private fun matchWrap() = LinearLayout.LayoutParams(-1, 52).apply { bottomMargin = 7 }
    private fun setStatus(message: String) = runOnUiThread { status.text = message }
    private fun setProgress(percent: Int, label: String) = runOnUiThread { progress.progress = percent.coerceIn(0,100); progressText.text = label }
    private fun setTransferActive(active: Boolean) = runOnUiThread { cancelButton.isEnabled = active }
    private fun toast(message: String) = runOnUiThread { Toast.makeText(this, message, Toast.LENGTH_LONG).show() }

    private fun hasPermissions(): Boolean {
        val required = if (Build.VERSION.SDK_INT >= 33) listOf(Manifest.permission.NEARBY_WIFI_DEVICES) else listOf(Manifest.permission.ACCESS_FINE_LOCATION)
        return required.all { checkSelfPermission(it) == PackageManager.PERMISSION_GRANTED }
    }
    private fun askPermissions() {
        val required = if (Build.VERSION.SDK_INT >= 33) listOf(Manifest.permission.NEARBY_WIFI_DEVICES) else listOf(Manifest.permission.ACCESS_FINE_LOCATION)
        val missing = required.filter { checkSelfPermission(it) != PackageManager.PERMISSION_GRANTED }
        if (missing.isNotEmpty()) requestPermissions(missing.toTypedArray(), 90) else registerP2pReceiver()
    }
    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == 90 && hasPermissions()) registerP2pReceiver() else toast("Wi-Fi Direct အသုံးပြုရန် Permission လိုအပ်ပါတယ်")
    }
    private fun registerP2pReceiver() {
        if (receiverRegistered) return
        val filter = IntentFilter().apply {
            addAction(WifiP2pManager.WIFI_P2P_STATE_CHANGED_ACTION)
            addAction(WifiP2pManager.WIFI_P2P_PEERS_CHANGED_ACTION)
            addAction(WifiP2pManager.WIFI_P2P_CONNECTION_CHANGED_ACTION)
        }
        if (Build.VERSION.SDK_INT >= 33) registerReceiver(p2pReceiver, filter, Context.RECEIVER_NOT_EXPORTED) else registerLegacyReceiver(filter)
        receiverRegistered = true
    }
    @Suppress("DEPRECATION")
    private fun registerLegacyReceiver(filter: IntentFilter) { registerReceiver(p2pReceiver, filter) }

    private fun discoverPeers() {
        if (!hasPermissions()) { askPermissions(); return }
        devices.removeAllViews()
        setStatus("ဖုန်းများကို ရှာဖွေနေပါတယ်… ဖုန်းနှစ်လုံးစလုံးမှာ Find Devices နှိပ်ပါ")
        manager.discoverPeers(channel, object : WifiP2pManager.ActionListener {
            override fun onSuccess() { setStatus("ရှာဖွေနေပါတယ်…") }
            override fun onFailure(reason: Int) { setStatus("ရှာမတွေ့ပါ • Error $reason • Wi-Fi ဖွင့်ထားပါ") }
        })
    }
    private fun requestPeers() {
        if (!hasPermissions()) return
        manager.requestPeers(channel) { list ->
            runOnUiThread {
                devices.removeAllViews()
                if (list.deviceList.isEmpty()) devices.addView(TextView(this).apply { text = "ဖုန်းမတွေ့သေးပါ။ နှစ်ဖုန်းလုံးမှာ Find Devices နှိပ်ပါ။"; setTextColor(0xFF68758A.toInt()); setPadding(8,18,8,18) })
                list.deviceList.forEach { device ->
                    val row = Button(this).apply {
                        text = "${device.deviceName}\n${device.deviceAddress}  •  ${device.statusLabel()}"
                        isAllCaps = false; gravity = Gravity.START or Gravity.CENTER_VERTICAL; textSize = 13f
                        setOnClickListener { connect(device) }
                    }
                    devices.addView(row, LinearLayout.LayoutParams(-1, 68).apply { bottomMargin = 6 })
                }
            }
        }
    }
    private fun WifiP2pDevice.statusLabel() = when(status) {
        WifiP2pDevice.AVAILABLE -> "Available"; WifiP2pDevice.CONNECTED -> "Connected"; WifiP2pDevice.INVITED -> "Invited"; else -> "Not available"
    }
    private fun connect(device: WifiP2pDevice) {
        val config = WifiP2pConfig().apply { deviceAddress = device.deviceAddress; wps.setup = WpsInfo.PBC; groupOwnerIntent = 0 }
        setStatus("${device.deviceName} ကို ချိတ်ဆက်နေပါတယ်…")
        manager.connect(channel, config, object : WifiP2pManager.ActionListener {
            override fun onSuccess() { setStatus("ချိတ်ဆက်ရန် တောင်းဆိုပြီးပါပြီ…") }
            override fun onFailure(reason: Int) { setStatus("ချိတ်ဆက်မရပါ • Error $reason") }
        })
    }

    private fun startServerIfOwner() {
        if (!groupOwner || !running.compareAndSet(false, true)) return
        executor.execute {
            try {
                serverSocket = ServerSocket(PORT)
                serverSocket?.reuseAddress = true
                while (running.get()) {
                    val incoming = serverSocket?.accept() ?: break
                    executor.execute { receiveFiles(incoming) }
                }
            } catch (_: Exception) { if (running.get()) setStatus("လက်ခံစနစ် ရပ်သွားပါတယ်") }
        }
    }
    private fun stopServer() {
        running.set(false)
        try { serverSocket?.close() } catch (_: Exception) {}
        serverSocket = null
    }

    private fun receiveFiles(socket: Socket) {
        if (!receiverBusy.compareAndSet(false, true)) { try { DataOutputStream(socket.getOutputStream()).writeBoolean(false) } catch (_: Exception) {}; socket.close(); return }
        transferSocket = socket
        cancelled.set(false)
        setTransferActive(true)
        try {
            socket.tcpNoDelay = true
            socket.receiveBufferSize = BUFFER_SIZE
            val input = DataInputStream(BufferedInputStream(socket.getInputStream(), BUFFER_SIZE))
            val output = DataOutputStream(BufferedOutputStream(socket.getOutputStream()))
            while (!cancelled.get()) {
                val name = try { input.readUTF().take(240).replace(Regex("[/\\\\]"), "_") } catch (_: EOFException) { break }
                val mime = input.readUTF().take(120)
                val size = input.readLong()
                if (size < 0L || size > MAX_FILE_SIZE) throw IOException("ဖိုင်အရွယ်အစား မမှန်ပါ")
                val accepted = askReceiveApproval(name, size)
                output.writeBoolean(accepted); output.flush()
                if (!accepted) { setStatus("ဖိုင်လက်ခံရန် ငြင်းပယ်လိုက်ပါတယ် • $name"); continue }
                val values = ContentValues().apply {
                    put(MediaStore.Downloads.DISPLAY_NAME, uniqueName(name))
                    put(MediaStore.Downloads.MIME_TYPE, mime.ifBlank { "application/octet-stream" })
                    put(MediaStore.Downloads.RELATIVE_PATH, "Download/S")
                }
                val uri = contentResolver.insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, values) ?: throw IOException("သိမ်းဆည်းရန် ဖိုင်မဖန်တီးနိုင်ပါ")
                try {
                    contentResolver.openOutputStream(uri, "w")!!.use { fileOut ->
                        val buffer = ByteArray(BUFFER_SIZE)
                        var remaining = size; var done = 0L; val start = System.nanoTime()
                        while (remaining > 0L && !cancelled.get()) {
                            val count = input.read(buffer, 0, minOf(buffer.size.toLong(), remaining).toInt())
                            if (count < 0) throw EOFException("ချိတ်ဆက်မှု ပြတ်သွားပါတယ်")
                            fileOut.write(buffer, 0, count); remaining -= count; done += count
                            val pct = if (size == 0L) 100 else (done * 100 / size).toInt()
                            val sec = max(0.1, (System.nanoTime() - start) / 1_000_000_000.0)
                            setProgress(pct, "Receiving • $pct% • ${"%.1f".format(done / sec / 1_000_000.0)} MB/s")
                        }
                        fileOut.flush()
                        if (cancelled.get()) throw IOException("Transfer cancelled")
                    }
                    setProgress(100, "Received • $name")
                    toast("လက်ခံပြီးပါပြီ • Download/S ထဲမှာရှိပါတယ်")
                } catch (e: Exception) { contentResolver.delete(uri, null, null); throw e }
            }
        } catch (e: Exception) { if (!cancelled.get()) toast("လက်ခံမှု မအောင်မြင်ပါ: ${e.message}") }
        finally { try { socket.close() } catch (_: Exception) {}; transferSocket = null; receiverBusy.set(false); setTransferActive(false) }
    }

    private fun askReceiveApproval(name: String, size: Long): Boolean {
        val latch = CountDownLatch(1)
        val answer = AtomicBoolean(false)
        runOnUiThread {
            if (isFinishing || isDestroyed) { latch.countDown(); return@runOnUiThread }
            AlertDialog.Builder(this)
                .setTitle("ဖိုင်လက်ခံမလား?")
                .setMessage("ဖိုင်: $name\nအရွယ်အစား: ${formatSize(size)}\n\nဒီဖိုင်ကို လက်ခံမလား?")
                .setPositiveButton("လက်ခံမယ်") { _, _ -> answer.set(true); latch.countDown() }
                .setNegativeButton("ငြင်းမယ်") { _, _ -> answer.set(false); latch.countDown() }
                .setOnCancelListener { answer.set(false); latch.countDown() }
                .show()
        }
        latch.await(2, TimeUnit.MINUTES)
        return answer.get()
    }
    private fun formatSize(bytes: Long): String = String.format("%.2f MB", bytes / 1024.0 / 1024.0)
    private fun uniqueName(original: String): String = original.substringAfterLast('/').ifBlank { "S_received_file" }

    private fun openFilePicker() {
        val intent = Intent(Intent.ACTION_OPEN_DOCUMENT).apply { addCategory(Intent.CATEGORY_OPENABLE); type = "*/*"; putExtra(Intent.EXTRA_ALLOW_MULTIPLE, true) }
        startActivityForResult(intent, 41)
    }
    @Deprecated("Deprecated API retained for Android 10 compatibility")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == 41 && resultCode == RESULT_OK && data != null) {
            val selected = mutableListOf<Uri>()
            data.clipData?.let { clip -> for (i in 0 until clip.itemCount) selected.add(clip.getItemAt(i).uri) }
            if (selected.isEmpty()) data.data?.let { selected.add(it) }
            if (selected.isNotEmpty()) sendFiles(selected.distinct())
        }
    }
    private fun sendFiles(uris: List<Uri>) {
        val address = remoteAddress
        if (!connected || groupOwner || address == null) { toast("ပို့မည့်ဖုန်းက Wi-Fi Direct Group Owner မဟုတ်ရပါ။ ပြန်ချိတ်ဆက်ကြည့်ပါ။"); return }
        if (!cancelled.compareAndSet(false, true)) return
        cancelled.set(false)
        setTransferActive(true)
        executor.execute {
            try {
                uris.forEachIndexed { index, uri ->
                    if (cancelled.get()) throw IOException("Transfer cancelled")
                    val name = queryName(uri)
                    val size = contentResolver.openAssetFileDescriptor(uri, "r")?.use { it.length } ?: -1L
                    if (size < 0L) throw IOException("ဖိုင်အရွယ်အစား မဖတ်နိုင်ပါ: $name")
                    val mime = contentResolver.getType(uri) ?: "application/octet-stream"
                    setProgress(0, "Connecting • ${index + 1}/${uris.size} • $name")
                    val socket = Socket(); transferSocket = socket
                    var lastConnectError: Exception? = null
                    for (attempt in 1..5) {
                        try {
                            socket.connect(java.net.InetSocketAddress(address, PORT), 12000)
                            lastConnectError = null
                            break
                        } catch (e: Exception) {
                            lastConnectError = e
                            if (attempt < 5 && !cancelled.get()) Thread.sleep(500)
                        }
                    }
                    if (lastConnectError != null) throw IOException("လက်ခံမည့်ဖုန်းနှင့် မချိတ်ဆက်နိုင်ပါ", lastConnectError)
                    socket.tcpNoDelay = true
                    socket.sendBufferSize = BUFFER_SIZE
                    val output = DataOutputStream(BufferedOutputStream(socket.getOutputStream(), BUFFER_SIZE))
                    val input = DataInputStream(BufferedInputStream(socket.getInputStream()))
                    output.writeUTF(name); output.writeUTF(mime); output.writeLong(size); output.flush()
                    if (!input.readBoolean()) { socket.close(); transferSocket = null; toast("လက်ခံသူက ငြင်းပယ်လိုက်ပါတယ် • $name"); return@forEachIndexed }
                    contentResolver.openInputStream(uri)!!.use { fileIn ->
                        val buffer = ByteArray(BUFFER_SIZE); var done = 0L; val start = System.nanoTime()
                        while (!cancelled.get()) {
                            val count = fileIn.read(buffer)
                            if (count < 0) break
                            output.write(buffer, 0, count); done += count
                            val pct = if (size == 0L) 100 else (done * 100 / size).toInt()
                            val sec = max(0.1, (System.nanoTime() - start) / 1_000_000_000.0)
                            setProgress(pct, "Sending ${index + 1}/${uris.size} • $pct% • ${"%.1f".format(done / sec / 1_000_000.0)} MB/s")
                        }
                        output.flush()
                    }
                    if (cancelled.get()) throw IOException("Transfer cancelled")
                    socket.shutdownOutput(); socket.close(); transferSocket = null
                    setProgress(100, "Sent ${index + 1}/${uris.size} • $name")
                }
                toast("ဖိုင် ${uris.size} ခု ပို့ပြီးပါပြီ")
            } catch (e: Exception) { if (!cancelled.get()) toast("ပို့မရပါ: ${e.message}"); setProgress(0, if (cancelled.get()) "Cancelled" else "Transfer failed") }
            finally { transferSocket?.let { try { it.close() } catch (_: Exception) {} }; transferSocket = null; cancelled.set(false); setTransferActive(false) }
        }
    }
    private fun cancelTransfer() {
        cancelled.set(true)
        try { transferSocket?.close() } catch (_: Exception) {}
        setProgress(0, "Cancelling…")
        setTransferActive(false)
    }
    private fun queryName(uri: Uri): String {
        var name = "S_file"
        val cursor: Cursor? = contentResolver.query(uri, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)
        cursor?.use { if (it.moveToFirst()) name = it.getString(0) ?: name }
        return name
    }

    override fun onDestroy() {
        super.onDestroy()
        cancelled.set(true)
        try { transferSocket?.close() } catch (_: Exception) {}
        stopServer()
        if (receiverRegistered) try { unregisterReceiver(p2pReceiver) } catch (_: Exception) {}
        executor.shutdownNow()
    }
    companion object {
        private const val PORT = 8988
        private const val BUFFER_SIZE = 1024 * 1024
        private const val MAX_FILE_SIZE = 50L * 1024 * 1024 * 1024
    }
}
