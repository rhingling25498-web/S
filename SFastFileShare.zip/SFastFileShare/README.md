# S – Wi-Fi Direct File Share

Android 10+ offline file transfer project. App label: **S**. In-app credit: **Created by LawShingLing MTS**.

## Build in Android Studio
1. Extract `SFastFileShare.zip`.
2. Open the extracted `SFastFileShare` folder in Android Studio.
3. Use JDK 17 and Android SDK Platform 35; allow Gradle sync.
4. Select **Build > Build Bundle(s) / APK(s) > Build APK(s)**.

## Build with GitHub Actions
Upload both `SFastFileShare.zip` and `SFastFileShare-build.yml` to the root of your GitHub repository. Rename the workflow file to `.github/workflows/build.yml` in GitHub (create the folders if needed). Run **Actions > Build S APK > Run workflow**. The workflow extracts the ZIP itself, builds the debug APK, and uploads `S-debug-apk` as an artifact.

## Wi-Fi Direct use
1. Install S on two Android 10+ phones and turn Wi-Fi on. No mobile data or internet connection is used for the transfer.
2. Open S on both phones and grant the requested Nearby Wi-Fi permission (Android 13+) or Location permission (Android 10–12). Android 10–12 may also require Location services to be switched on for peer discovery.
3. On both phones, tap **Find Devices**. From the phone that will send, tap the other phone in the list and accept the Android connection prompt if one appears.
4. The app requests the other phone to act as Wi-Fi Direct group owner. The group-owner phone is the receiver; the connecting phone is the sender.
5. On the sender, tap **Send Files**, select one or more files, and keep both phones awake with S open. On the receiver, accept or reject each incoming file.
6. Received files are saved in `Download/S`.
7. Tap **Cancel** to stop an active transfer. An incomplete received file is deleted.

## Current implementation
- Wi-Fi Direct peer discovery and connection.
- TCP streaming over the Wi-Fi Direct group link using a 1 MiB buffer; file bytes are not loaded entirely into memory.
- Multiple selected files, per-file accept/reject, progress percentage, live MB/s estimate, and cancel.
- Files up to 50 GiB are accepted by the app's protocol, subject to available storage and Android document-provider support.

## Important limitations
- This initial Wi-Fi Direct flow deliberately makes the connecting phone the sender and the group-owner phone the receiver. To reverse direction, disconnect and reconnect with the other phone initiating the connection. Some Android manufacturers may not honor group-owner preference consistently; if the role is reversed, disconnect and retry from the intended sender.
- Pause/resume, transfer history, QR pairing, and simultaneous two-way transfers are not implemented in this build.
- 1 GB in 10 seconds requires about 800 Mbps of sustained payload throughput. That speed depends on both phones' Wi-Fi hardware, Wi-Fi Direct implementation, signal conditions, and interference; it cannot be guaranteed.
- This project has not yet been installed and tested on physical phones in this environment. Test the first transfer with a small file before sending large files.
